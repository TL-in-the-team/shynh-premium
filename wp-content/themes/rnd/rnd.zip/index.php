<?php /* Template Name:  Home Page*/  ?>
<?php get_header() ?>
<section class="sbanner">
    <div class="container">
        <!-- <h1 class="maintit">Our Services</h1> -->
        <!-- <?php 
            echo imageEncode('/images/icon-tit.png');
        ?> -->
    </div>
</section>
<?php get_footer() ?>